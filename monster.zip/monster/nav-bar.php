

<header class="nav-bar">
	<div class="inner-column">
		<picture>
			<?php include('svg.php');?>
		</picture>
		<h1 class="header big-text">Monster Adoption Agency</h1>
	</div>
</header>
