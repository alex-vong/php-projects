      <?php

      $codey = [
        "id" => 8,
        "name" => "Codey",
        "favoriteFood" => "Mountain Dew Code Red",
        "age" => 7,
        "adopted" => true,
        "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/codey.jpg",
      ];

      $lima = [
        "id" => 24,
        "name" => "Lima Bean",
        "favoriteFood" => "Pistachio Ice Cream",
        "age" => 4,
        "adopted" => false,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/limabean.jpg",
      ];

      $reads = [
        "id" => 9,
        "name" => "Miss Sassy Bossy Pants",
        "favoriteFood" => "Alphabet Soup",
        "age" => 9,
        "adopted" => true,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/miss-reads-a-lot.jpg",
      ];

      $fragoo = [
        "id" => 87,
        "name" => "Fragoo",
        "favoriteFood" => "Fish tacos",
        "age" => 8,
        "adopted" => false,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/fragoo.jpg",
      ];

      $bananas = [
        "id" => 34,
        "name" => "Mr. Bananas",
        "favoriteFood" => "Watermelons",
        "age" => 10,
        "adopted" => false,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/mr-banana.jpg",
      ];

      $origina = [
        "id" => 30,
        "name" => "Origina",
        "favoriteFood" => "Chili Cheese Fries",
        "age" => 6,
        "adopted" => true,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/orangina.jpg",
      ];

      $shadow = [
        "id" => 12,
        "name" => "Shadow",
        "favoriteFood" => "Orange Soda",
        "age" => 5,
        "adopted" => false,
         "portrait" => "https://peprojects.dev/alpha-1/alexvong/portraits/shadow.jpg",
      ];

    $monsters = [$codey, $lima, $reads, $fragoo, $shadow, $bananas, $origina];